# Rights notice

- Team artifact: three residual-head state dictionaries and their routing metadata.
- Upstream dependency: FeatDistill Expert 4; not bundled, not rebranded, redistribution authorization unproven.
- Commercial-data blockers: 9,311 Open Images bulk rows used a source-level CC BY assertion without item-by-item verification; 986 precomputed guided-diffusion/BigGAN sample pixels have no explicit data-specific licence, and 682 of those were used for gradients in the large-image heads.
- Required remediation: reverify or replace the bulk Open Images rows, remove or replace all 986 ambiguous generated records, rerun the affected training and untouched regression audit, then issue a new version with new hashes.
- Evaluation data: CIFAKE and SID terms are documented in the repository rights matrix. WildFake remains evaluation-only; no WildFake pixels are redistributed.

This notice records the project's evidence boundary and is not legal advice.
