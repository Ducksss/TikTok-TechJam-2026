# SynthFlag TEST1 head bundle v1

This bundle contains the **three lightweight residual heads required to replay the selected TEST1 scoring graph**. It does not contain the frozen image encoder or any of the four upstream FeatDistill expert checkpoints.

## Routing contract

- Native longest side at most 64 pixels: `cifake_router_head.pt`, residual alpha 1.25.
- Native longest side above 64 pixels: compute corrected margins from `general_epoch05_head.pt` and `general_epoch08_head.pt`, then combine them as `0.65 × epoch05 + 0.35 × epoch08`.
- Convert the selected large-image margin using the frozen calibration offset `-1.557959395647049`; the public TEST1 decision rule is probability at least 0.5.
- Each head consumes a 1,152-dimensional pooled feature plus the upstream teacher margin.

The exact file hashes and original checkpoint hashes are recorded in `head_bundle_manifest.json`.

## Provenance boundary

These small heads were trained by the SynthFlag project over frozen features. The required Expert 4 feature encoder is an upstream FeatDistill checkpoint and is not included here. Its redistribution permission is not established by the published source-code licence, so obtain it from the authors' official release and review its terms independently.

## Rights status

This is an experimental research artifact, **not an unqualified commercial-cleared release**. The large-image epoch-05/08 lineage includes a 9,311-image Open Images bulk tranche that used a source-level CC BY assertion without item-by-item verification. It also included 682 gradient rows from a 986-image precomputed guided-diffusion/BigGAN sample source whose pixel licence is not explicit. A strict commercial-only release requires reverifying or replacing these rows and retraining the affected heads. The CIFAKE router head used the MIT-published CIFAKE training split, but still depends on the separately licensed upstream encoder.

No benchmark pixels are included in this archive.
